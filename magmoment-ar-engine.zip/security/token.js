export async function resolveToken(){
 return { valid:true, frameId:"default", videoUrl:"./assets/videos/demo.mp4" };
}